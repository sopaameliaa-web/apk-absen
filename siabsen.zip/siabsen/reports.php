<?php
require_once __DIR__.'/includes/functions.php'; require_login();
$u=current_user();$from=$_GET['from']??date('Y-m-01');$to=$_GET['to']??date('Y-m-d');$kind=$_GET['kind']??'gate';
if(!in_array($kind,['gate','lesson'],true))$kind='gate';
$params=[$from,$to];
if($kind==='gate'){
$sql="SELECT g.attendance_date AS tanggal,g.scanned_at AS waktu,g.person_type AS jenis,CASE WHEN g.person_type='student' THEN s.full_name ELSE t.full_name END AS nama,CASE WHEN g.person_type='student' THEN c.name ELSE '-' END AS kelas,g.attendance_type AS tipe,g.photo_path AS foto FROM gate_attendance g LEFT JOIN students s ON g.person_type='student' AND s.id=g.person_id LEFT JOIN school_classes c ON c.id=s.class_id LEFT JOIN teachers t ON g.person_type='teacher' AND t.id=g.person_id WHERE g.attendance_date BETWEEN ? AND ?";
}else{
$sql="SELECT l.lesson_date AS tanggal,l.meeting_no AS pertemuan,s.full_name AS nama,c.name AS kelas,sub.name AS mapel,t.full_name AS guru,l.status,l.note FROM lesson_attendance l JOIN students s ON s.id=l.student_id JOIN school_classes c ON c.id=l.class_id JOIN subjects sub ON sub.id=l.subject_id JOIN teachers t ON t.id=l.teacher_id WHERE l.lesson_date BETWEEN ? AND ?";
}
if($u['role']==='wali'){
$st=db()->prepare('SELECT id FROM school_classes WHERE homeroom_user_id=?');$st->execute([$u['id']]);$classIds=$st->fetchAll(PDO::FETCH_COLUMN);
if(!$classIds && !empty($u['class_id']))$classIds=[$u['class_id']];
if($classIds){$sql.=' AND '.($kind==='gate'?'s.class_id':'l.class_id').' IN ('.implode(',',array_fill(0,count($classIds),'?')).')';$params=array_merge($params,$classIds);}else{$sql.=' AND 1=0';}
}
$sql.=' ORDER BY tanggal DESC LIMIT 5000';$st=db()->prepare($sql);$st->execute($params);$rows=$st->fetchAll();
layout_header('Rekap Absensi');echo '<h1 class="h3 mb-3">Rekap absensi</h1><form class="card card-body mb-3"><div class="row g-3 align-items-end"><div class="col-md-3"><label class="form-label">Jenis laporan</label><select name="kind" class="form-select"><option value="gate" '.($kind==='gate'?'selected':'').'>Datang / pulang gerbang</option><option value="lesson" '.($kind==='lesson'?'selected':'').'>Absensi pertemuan</option></select></div><div class="col-md-3"><label class="form-label">Dari tanggal</label><input type="date" name="from" class="form-control" value="'.e($from).'"></div><div class="col-md-3"><label class="form-label">Sampai tanggal</label><input type="date" name="to" class="form-control" value="'.e($to).'"></div><div class="col-md-3"><button class="btn btn-primary">Tampilkan</button></div></div></form><div class="d-flex gap-2 flex-wrap mb-3"><a class="btn btn-outline-success" href="'.e(url('export.php?'.http_build_query(['kind'=>$kind,'from'=>$from,'to'=>$to,'format'=>'csv']))).'">Unduh Excel/CSV</a><button class="btn btn-outline-secondary" onclick="window.print()">Cetak / Simpan PDF</button></div><div class="card"><div class="table-responsive"><table class="table table-striped mb-0"><thead><tr>';
$headers=$rows?array_keys($rows[0]):($kind==='gate'?['tanggal','waktu','jenis','nama','kelas','tipe','foto']:['tanggal','pertemuan','nama','kelas','mapel','guru','status','note']);foreach($headers as $h)echo '<th>'.e(strtoupper($h)).'</th>';echo '</tr></thead><tbody>';
foreach($rows as $r){echo '<tr>';foreach($r as $k=>$v){if($k==='foto'&&$v)echo '<td><a target="_blank" rel="noopener" href="'.e(url($v)).'">Lihat foto</a></td>';else echo '<td>'.e((string)$v).'</td>';}echo '</tr>';}if(!$rows)echo '<tr><td colspan="10" class="text-center text-secondary py-4">Tidak ada data pada rentang tanggal tersebut.</td></tr>';echo '</tbody></table></div></div><p class="small text-secondary mt-2">Maksimum 5.000 baris per laporan. Filter wali kelas dibatasi ke kelas yang ditugaskan.</p>';layout_footer();
