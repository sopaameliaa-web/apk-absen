<?php
require_once __DIR__.'/includes/functions.php'; require_login();
$today=date('Y-m-d');
$students=(int)db()->query('SELECT COUNT(*) FROM students WHERE active=1')->fetchColumn();
$teachers=(int)db()->query('SELECT COUNT(*) FROM teachers WHERE active=1')->fetchColumn();
$st=db()->prepare("SELECT COUNT(*) FROM gate_attendance WHERE attendance_date=? AND attendance_type='in' AND person_type='student'"); $st->execute([$today]); $present=(int)$st->fetchColumn();
$st=db()->prepare("SELECT COUNT(*) FROM gate_attendance WHERE attendance_date=? AND attendance_type='in' AND person_type='teacher'"); $st->execute([$today]); $teacherPresent=(int)$st->fetchColumn();
layout_header('Dashboard');
echo '<div class="d-flex flex-wrap justify-content-between align-items-center mb-4"><div><h1 class="h3 fw-bold mb-1">Dashboard</h1><p class="text-secondary mb-0">Ringkasan absensi · '.e(date('d M Y')).'</p></div><a class="btn btn-primary mt-2" href="'.e(url('scan.php')).'">Buka scan gerbang</a></div>';
echo '<div class="row g-3 mb-4">';
$cards=[['Total siswa',$students,'people','primary'],['Total guru',$teachers,'person-workspace','success'],['Siswa absen datang',$present,'check-circle','info'],['Guru absen datang',$teacherPresent,'calendar-check','warning']];
foreach($cards as $c) echo '<div class="col-6 col-xl-3"><div class="card stat-card h-100"><div class="card-body"><div class="text-secondary small">'.e($c[0]).'</div><div class="display-6 fw-bold">'.e((string)$c[1]).'</div><div class="small text-primary">Data hari ini</div></div></div></div>';
echo '</div><div class="row g-3"><div class="col-lg-8"><div class="card"><div class="card-body"><h2 class="h5">Akses cepat</h2><div class="d-flex flex-wrap gap-2"><a class="btn btn-outline-primary" href="'.e(url('reports.php')).'">Lihat rekap</a><a class="btn btn-outline-primary" href="'.e(url('documents.php')).'">Dokumen sekolah</a>';
if(current_user()['role']==='admin') echo '<a class="btn btn-outline-primary" href="'.e(url('manage.php')).'">Kelola data master</a>';
if(in_array(current_user()['role'],['admin','guru'],true)) echo '<a class="btn btn-outline-primary" href="'.e(url('class_attendance.php')).'">Absensi pertemuan</a>';
echo '</div></div></div></div><div class="col-lg-4"><div class="card"><div class="card-body"><h2 class="h5">Informasi</h2><p class="small text-secondary mb-0">Gunakan rekap untuk memeriksa catatan datang/pulang dan kehadiran tiap pertemuan. Pastikan data kelas, guru, dan mata pelajaran sudah benar.</p></div></div></div></div>';
layout_footer();
