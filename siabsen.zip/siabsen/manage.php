<?php
require_once __DIR__.'/includes/functions.php'; require_roles(['admin']);
$types=[
 'students'=>['title'=>'Siswa','table'=>'students','fields'=>['nis'=>'NIS','full_name'=>'Nama lengkap','class_id'=>'Kelas','gender'=>'Jenis kelamin'],'columns'=>'s.id,s.nis,s.full_name,c.name AS class_name,s.gender,s.active','joins'=>' JOIN school_classes c ON c.id=s.class_id','alias'=>'s'],
 'teachers'=>['title'=>'Guru','table'=>'teachers','fields'=>['nip'=>'NIP','full_name'=>'Nama lengkap','email'=>'Email','phone'=>'Telepon'],'columns'=>'t.id,t.nip,t.full_name,t.email,t.phone,t.active','joins'=>'','alias'=>'t'],
 'classes'=>['title'=>'Kelas','table'=>'school_classes','fields'=>['name'=>'Nama kelas','grade_level'=>'Tingkat'],'columns'=>'c.id,c.name,c.grade_level','joins'=>'','alias'=>'c'],
 'subjects'=>['title'=>'Mata pelajaran','table'=>'subjects','fields'=>['name'=>'Nama mapel','subject_code'=>'Kode mapel'],'columns'=>'s.id,s.name,s.subject_code','joins'=>'','alias'=>'s'],
 'users'=>['title'=>'Akun pengguna','table'=>'users','fields'=>['username'=>'Username','full_name'=>'Nama lengkap','role'=>'Peran'],'columns'=>'u.id,u.username,u.full_name,u.role,u.active','joins'=>'','alias'=>'u']
];
$type=$_GET['type']??'students'; if(!isset($types[$type])) $type='students'; $cfg=$types[$type]; $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf(); $action=$_POST['action']??'';
 try{
  if($action==='save'){
   $id=(int)($_POST['id']??0); $data=[];
   foreach($cfg['fields'] as $key=>$label){$v=trim((string)($_POST[$key]??'')); if($v==='') throw new RuntimeException("$label wajib diisi."); $data[$key]=$v;}
   if($type==='students') $data['qr_token']=bin2hex(random_bytes(32));
   if($type==='teachers') $data['qr_token']=bin2hex(random_bytes(32));
   if($type==='users'){
    if(!in_array($data['role'],['admin','guru','wali'],true)) throw new RuntimeException('Peran tidak valid.');
    $hash=password_hash((string)($_POST['password']??'ChangeMe123!'),PASSWORD_DEFAULT);
    if($id){$st=db()->prepare('UPDATE users SET username=?,full_name=?,role=?'.(!empty($_POST['password'])?',password_hash=?':'').' WHERE id=?');$args=[$data['username'],$data['full_name'],$data['role']];if(!empty($_POST['password']))$args[]=$hash;$args[]=$id;$st->execute($args);}
    else {$st=db()->prepare('INSERT INTO users(username,password_hash,full_name,role) VALUES(?,?,?,?)');$st->execute([$data['username'],$hash,$data['full_name'],$data['role']]);}
   } else {
    if($id){$sets=[];$args=[];foreach($data as $k=>$v){$sets[]="$k=?";$args[]=$v;}$args[]=$id;$st=db()->prepare('UPDATE '.$cfg['table'].' SET '.implode(',',$sets).' WHERE id=?');$st->execute($args);}
    else {$keys=array_keys($data);$st=db()->prepare('INSERT INTO '.$cfg['table'].'('.implode(',',$keys).') VALUES('.implode(',',array_fill(0,count($keys),'?')).')');$st->execute(array_values($data));}
   }
   flash('Data berhasil disimpan.'); redirect('manage.php?type='.$type);
  } elseif($action==='delete'){
   $id=(int)$_POST['id']; if($type==='users' && $id===(int)current_user()['id']) throw new RuntimeException('Tidak dapat menghapus akun sendiri.');
   $st=db()->prepare('DELETE FROM '.$cfg['table'].' WHERE id=?');$st->execute([$id]);flash('Data dihapus.');redirect('manage.php?type='.$type);
  }
 }catch(Throwable $ex){$error='Tidak dapat menyimpan data. Pastikan isian valid dan tidak duplikat. Detail: '.$ex->getMessage();}
}
$search=trim((string)($_GET['q']??'')); $alias=$cfg['alias'];
$sql='SELECT '.$cfg['columns'].' FROM '.$cfg['table'].' '.$alias.$cfg['joins'];
$params=[];
if($search!==''){ $cols=match($type){'students'=>'s.nis LIKE ? OR s.full_name LIKE ?','teachers'=>'t.nip LIKE ? OR t.full_name LIKE ?','classes'=>'c.name LIKE ?','subjects'=>'s.name LIKE ? OR s.subject_code LIKE ?','users'=>'u.username LIKE ? OR u.full_name LIKE ?'}; $sql.=' WHERE '.$cols; for($i=0;$i<substr_count($cols,'?');$i++)$params[]='%'.$search.'%';}
$sql.=' ORDER BY 1 DESC LIMIT 300';$st=db()->prepare($sql);$st->execute($params);$rows=$st->fetchAll();
layout_header('Data Master'); echo '<div class="d-flex flex-wrap justify-content-between align-items-center mb-3"><h1 class="h3">Data Master</h1></div><div class="d-flex flex-wrap gap-2 mb-3">';
foreach($types as $k=>$v) echo '<a class="btn btn-sm '.($k===$type?'btn-primary':'btn-outline-primary').'" href="'.e(url('manage.php?type='.$k)).'">'.e($v['title']).'</a>';
echo '</div>';
if($error)echo '<div class="alert alert-danger">'.e($error).'</div>';
echo '<div class="card mb-4"><div class="card-body"><h2 class="h5">Tambah '.$cfg['title'].'</h2><form method="post" class="row g-3">'.csrf_field().'<input type="hidden" name="action" value="save">';
foreach($cfg['fields'] as $k=>$label){echo '<div class="col-md-4"><label class="form-label">'.e($label).'</label>';
if($k==='class_id'){echo '<select name="class_id" class="form-select" required><option value="">Pilih kelas</option>';foreach(db()->query('SELECT id,name FROM school_classes ORDER BY name') as $cl)echo '<option value="'.(int)$cl['id'].'">'.e($cl['name']).'</option>';echo '</select>';}
elseif($k==='gender')echo '<select name="gender" class="form-select" required><option value="L">Laki-laki</option><option value="P">Perempuan</option></select>';
elseif($k==='role')echo '<select name="role" class="form-select" required><option value="guru">Guru</option><option value="wali">Wali kelas</option><option value="admin">TU/Admin</option></select>';
else echo '<input class="form-control" name="'.e($k).'" required>';
echo '</div>';}
if($type==='users')echo '<div class="col-md-4"><label class="form-label">Kata sandi awal</label><input class="form-control" type="password" name="password" placeholder="ChangeMe123!"></div>';
echo '<div class="col-12"><button class="btn btn-primary">Simpan data</button></div></form></div></div>';
echo '<form class="row g-2 mb-3"><input type="hidden" name="type" value="'.e($type).'"><div class="col-sm-6"><input class="form-control" name="q" value="'.e($search).'" placeholder="Cari data..."></div><div class="col-auto"><button class="btn btn-outline-secondary">Cari</button></div></form>';
echo '<div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr>';
$headers=match($type){'students'=>['ID','NIS','Nama','Kelas','JK','Aktif'],'teachers'=>['ID','NIP','Nama','Email','Telepon','Aktif'],'classes'=>['ID','Kelas','Tingkat'],'subjects'=>['ID','Mata pelajaran','Kode'],'users'=>['ID','Username','Nama','Peran','Aktif']};
foreach($headers as $h)echo '<th>'.e($h).'</th>';echo '</tr></thead><tbody>';
foreach($rows as $r){echo '<tr>';foreach($r as $v)echo '<td>'.e((string)$v).'</td>';echo '</tr>';}
if(!$rows)echo '<tr><td colspan="8" class="text-center text-secondary py-4">Belum ada data.</td></tr>';
echo '</tbody></table></div></div><p class="small text-secondary mt-2">Untuk menjaga integritas relasi, data yang telah memiliki catatan absensi tidak dapat dihapus sebelum relasi terkait ditangani.</p>';
layout_footer();
