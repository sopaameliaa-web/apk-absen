<?php
require_once __DIR__.'/includes/functions.php';
try {
 $pdo=db();
 $count=(int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
 if($count===0){
  $pdo->beginTransaction();
  $pdo->exec("INSERT INTO school_classes(name,grade_level) VALUES ('VII-A','VII'),('VIII-A','VIII')");
  $pdo->exec("INSERT INTO subjects(name,subject_code) VALUES ('Matematika','MTK'),('Bahasa Indonesia','BIN')");
  $teacherToken=bin2hex(random_bytes(32));
  $st=$pdo->prepare('INSERT INTO teachers(nip,full_name,qr_token) VALUES(?,?,?)'); $st->execute(['19800101','Guru Contoh',$teacherToken]); $tid=(int)$pdo->lastInsertId();
  $st=$pdo->prepare('INSERT INTO users(username,password_hash,full_name,role,teacher_id) VALUES(?,?,?,?,?)');
  $st->execute(['admin',password_hash('Admin123!',PASSWORD_DEFAULT),'Administrator TU','admin',null]);
  $st->execute(['guru',password_hash('Guru123!',PASSWORD_DEFAULT),'Guru Contoh','guru',$tid]);
  $st->execute(['wali',password_hash('Wali123!',PASSWORD_DEFAULT),'Wali Kelas Contoh','wali',null]);
  $st2=$pdo->prepare('INSERT INTO students(nis,full_name,class_id,gender,qr_token) VALUES(?,?,?,?,?)');
  $st2->execute(['10001','Siswa Contoh',1,'L',bin2hex(random_bytes(32))]);
  $pdo->commit();
  $msg='Setup berhasil. Akun awal: admin/Admin123!, guru/Guru123!, wali/Wali123!. Hapus setup.php sekarang.';
 } else $msg='Database sudah memiliki akun. Setup tidak mengubah data.';
} catch(Throwable $e){ if(isset($pdo)&&$pdo->inTransaction())$pdo->rollBack(); $msg='Gagal setup: '.$e->getMessage(); }
?><!doctype html><html lang="id"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Setup SIABSEN</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><body class="container py-5"><div class="alert alert-info"><?=htmlspecialchars($msg,ENT_QUOTES,'UTF-8')?></div><a class="btn btn-primary" href="login.php">Ke halaman login</a></body></html>
