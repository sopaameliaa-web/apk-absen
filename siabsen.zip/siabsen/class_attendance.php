<?php
require_once __DIR__.'/includes/functions.php'; require_roles(['admin','guru']);
$u=current_user();$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();
 try{
  $classId=(int)($_POST['class_id']??0);$subjectId=(int)($_POST['subject_id']??0);$meeting=(int)($_POST['meeting_no']??0);$date=(string)($_POST['lesson_date']??'');$start=(string)($_POST['start_time']??'');$end=(string)($_POST['end_time']??'');
  if(!$classId||!$subjectId||$meeting<1||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date))throw new RuntimeException('Lengkapi kelas, mapel, tanggal, dan nomor pertemuan.');
  $st=db()->prepare('SELECT id FROM teachers WHERE id=? AND active=1');$st->execute([(int)($u['teacher_id']??0)]);$teacherId=(int)$st->fetchColumn();
  if($u['role']==='guru'&&!$teacherId)throw new RuntimeException('Akun guru belum dihubungkan ke data guru. Hubungkan teacher_id melalui database.');
  if($u['role']==='admin'){$teacherId=(int)($_POST['teacher_id']??0);if(!$teacherId)throw new RuntimeException('Pilih guru pengajar.');}
  $st=db()->prepare('SELECT id FROM students WHERE class_id=? AND active=1 ORDER BY full_name');$st->execute([$classId]);$ids=$st->fetchAll(PDO::FETCH_COLUMN);
  if(!$ids)throw new RuntimeException('Tidak ada siswa aktif di kelas ini.');
  $pdo=db();$pdo->beginTransaction();
  $save=$pdo->prepare("INSERT INTO lesson_attendance(class_id,student_id,teacher_id,subject_id,lesson_date,meeting_no,start_time,end_time,status,note,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE teacher_id=VALUES(teacher_id),class_id=VALUES(class_id),start_time=VALUES(start_time),end_time=VALUES(end_time),status=VALUES(status),note=VALUES(note)");
  foreach($ids as $sid){$status=$_POST['status'][$sid]??'alpa';if(!in_array($status,['hadir','terlambat','izin','sakit','alpa'],true))$status='alpa';$note=trim((string)($_POST['note'][$sid]??''));$save->execute([$classId,$sid,$teacherId,$subjectId,$date,$meeting,$start?:null,$end?:null,$status,substr($note,0,255),$u['id']]);}
  $pdo->commit();log_activity('Simpan absensi kelas '.$classId.' pertemuan '.$meeting);flash('Absensi kelas berhasil disimpan.');redirect('class_attendance.php');
 }catch(Throwable $e){if(isset($pdo)&&$pdo->inTransaction())$pdo->rollBack();$error='Gagal menyimpan: '.$e->getMessage();}
}
$classes=db()->query('SELECT id,name FROM school_classes ORDER BY name')->fetchAll();$subjects=db()->query('SELECT id,name FROM subjects ORDER BY name')->fetchAll();$teachers=db()->query('SELECT id,full_name FROM teachers WHERE active=1 ORDER BY full_name')->fetchAll();
$selected=(int)($_GET['class_id']??0);$students=[];
if($selected){$st=db()->prepare('SELECT id,nis,full_name FROM students WHERE class_id=? AND active=1 ORDER BY full_name');$st->execute([$selected]);$students=$st->fetchAll();}
layout_header('Absensi Kelas');echo '<h1 class="h3 mb-3">Absensi siswa per pertemuan</h1><p class="text-secondary">Pilih kelas, mata pelajaran, tanggal, dan pertemuan. Status tiap siswa tersimpan terpisah.</p>';
if($error)echo '<div class="alert alert-danger">'.e($error).'</div>';
echo '<form method="get" class="card card-body mb-3"><label class="form-label">Pilih kelas untuk memuat daftar siswa</label><div class="d-flex gap-2"><select name="class_id" class="form-select" required><option value="">Pilih kelas</option>';foreach($classes as $c)echo '<option value="'.$c['id'].'" '.($selected===$c['id']?'selected':'').'>'.e($c['name']).'</option>';echo '</select><button class="btn btn-outline-primary">Muat</button></div></form>';
if($selected && $students){echo '<form method="post" class="card"><div class="card-body">'.csrf_field().'<div class="row g-3 mb-4"><div class="col-md-3"><label class="form-label">Mata pelajaran</label><select name="subject_id" class="form-select" required><option value="">Pilih</option>';foreach($subjects as $s)echo '<option value="'.$s['id'].'">'.e($s['name']).'</option>';echo '</select></div><input type="hidden" name="class_id" value="'.$selected.'"><div class="col-md-2"><label class="form-label">Tanggal</label><input class="form-control" type="date" name="lesson_date" value="'.date('Y-m-d').'" required></div><div class="col-md-2"><label class="form-label">Pertemuan ke-</label><input class="form-control" type="number" min="1" max="100" name="meeting_no" value="1" required></div><div class="col-md-2"><label class="form-label">Jam mulai</label><input class="form-control" type="time" name="start_time"></div><div class="col-md-2"><label class="form-label">Jam selesai</label><input class="form-control" type="time" name="end_time"></div>';
if($u['role']==='admin'){echo '<div class="col-md-3"><label class="form-label">Guru pengajar</label><select name="teacher_id" class="form-select" required><option value="">Pilih guru</option>';foreach($teachers as $t)echo '<option value="'.$t['id'].'">'.e($t['full_name']).'</option>';echo '</select></div>';}echo '</div><div class="table-responsive"><table class="table align-middle"><thead><tr><th>NIS</th><th>Nama siswa</th><th>Status</th><th>Catatan</th></tr></thead><tbody>';
foreach($students as $s){echo '<tr><td>'.e($s['nis']).'</td><td>'.e($s['full_name']).'</td><td><select class="form-select" name="status['.$s['id'].']">';foreach(['hadir'=>'Hadir','terlambat'=>'Terlambat','izin'=>'Izin','sakit'=>'Sakit','alpa'=>'Alpa'] as $v=>$label)echo '<option value="'.$v.'">'.$label.'</option>';echo '</select></td><td><input class="form-control" name="note['.$s['id'].']" maxlength="255" placeholder="Opsional"></td></tr>';}
echo '</tbody></table></div><button class="btn btn-primary">Simpan absensi</button></div></form>';}elseif($selected)echo '<div class="alert alert-warning">Belum ada siswa aktif di kelas ini.</div>';
layout_footer();
