<?php
require_once __DIR__.'/includes/functions.php'; require_roles(['admin']);
layout_header('QR & Gerbang');
echo '<div class="row g-4"><div class="col-lg-5"><h1 class="h3">QR & Gerbang</h1><p class="text-secondary">Gunakan token QR unik sebagai identitas. Cetak halaman ini untuk membuat QR per orang.</p><div class="card"><div class="card-body"><form method="get" class="row g-2"><div class="col-8"><select name="type" class="form-select"><option value="student">Siswa</option><option value="teacher">Guru</option></select></div><div class="col-4"><button class="btn btn-primary w-100">Tampilkan</button></div></form></div></div></div><div class="col-lg-7"><div class="card"><div class="card-body"><h2 class="h5">Daftar QR</h2>';
$type=($_GET['type']??'student')==='teacher'?'teacher':'student';
if($type==='student'){$rows=db()->query('SELECT id,nis AS code,full_name,qr_token FROM students WHERE active=1 ORDER BY full_name')->fetchAll();}
else{$rows=db()->query('SELECT id,nip AS code,full_name,qr_token FROM teachers WHERE active=1 ORDER BY full_name')->fetchAll();}
echo '<div class="row g-3">';
foreach($rows as $r){$payload='SIABSEN:'.$type.':'.$r['qr_token'];echo '<div class="col-6 col-md-4 text-center qr-item"><div class="qr" data-qr="'.e($payload).'"></div><div class="fw-semibold">'.e($r['full_name']).'</div><div class="small text-secondary">'.e((string)$r['code']).'</div></div>';}
if(!$rows)echo '<p class="text-secondary">Belum ada data.</p>';
echo '</div><button class="btn btn-outline-primary mt-3" onclick="window.print()">Cetak QR</button></div></div></div><script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script><script>document.querySelectorAll(".qr").forEach(el=>new QRCode(el,{text:el.dataset.qr,width:130,height:130}));</script>';
layout_footer();
