<?php
require_once __DIR__.'/../includes/functions.php';
header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['ok'=>false,'message'=>'Metode tidak diizinkan']);exit;}
verify_csrf();
try{
 $token=(string)($_POST['token']??'');$type=(string)($_POST['attendance_type']??'');$photo=(string)($_POST['photo']??'');
 if(!in_array($type,['in','out'],true)||!preg_match('/^SIABSEN:(student|teacher):([a-f0-9]{64})$/',$token,$m))throw new RuntimeException('QR tidak valid.');
 $personType=$m[1];$qr=$m[2];$pdo=db();
 if($personType==='student')$st=$pdo->prepare('SELECT id,full_name FROM students WHERE qr_token=? AND active=1');
 else $st=$pdo->prepare('SELECT id,full_name FROM teachers WHERE qr_token=? AND active=1');
 $st->execute([$qr]);$person=$st->fetch();if(!$person)throw new RuntimeException('QR tidak terdaftar atau sudah dinonaktifkan.');
 if(!preg_match('/^data:image\/jpeg;base64,([A-Za-z0-9+\/=]+)$/',$photo,$pm))throw new RuntimeException('Foto kamera wajib disertakan.');
 $bytes=base64_decode($pm[1],true);if($bytes===false||strlen($bytes)<1000||strlen($bytes)>4*1024*1024)throw new RuntimeException('Ukuran foto tidak valid (maksimum 3 MB).');
 if(!is_dir(UPLOAD_DIR.'/absensi')&&!mkdir(UPLOAD_DIR.'/absensi',0750,true))throw new RuntimeException('Folder foto tidak dapat dibuat.');
 $filename=bin2hex(random_bytes(20)).'.jpg';$relative='uploads/absensi/'.$filename;
 if(file_put_contents(dirname(__DIR__).'/'.$relative,$bytes,LOCK_EX)===false)throw new RuntimeException('Foto gagal disimpan.');
 try{
  $st=$pdo->prepare('INSERT INTO gate_attendance(person_type,person_id,attendance_date,attendance_type,scanned_at,photo_path,recorded_by) VALUES(?,?,CURDATE(),?,NOW(),?,?)');
  $st->execute([$personType,$person['id'],$type,$relative,current_user()['id']??null]);
 }catch(Throwable $e){@unlink(dirname(__DIR__).'/'.$relative);if($e instanceof PDOException && $e->getCode()==='23000')throw new RuntimeException('Absensi jenis ini sudah tercatat hari ini.');throw $e;}
 echo json_encode(['ok'=>true,'message'=>'Absensi berhasil: '.$person['full_name'].' · '.($type==='in'?'Datang':'Pulang'),'name'=>$person['full_name'],'time'=>date('H:i:s')]);
}catch(Throwable $e){http_response_code(400);echo json_encode(['ok'=>false,'message'=>$e->getMessage()]);}
