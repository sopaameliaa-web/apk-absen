<?php
require_once __DIR__.'/includes/functions.php'; require_login();
$id=(int)($_GET['id']??0);$st=db()->prepare('SELECT * FROM documents WHERE id=?');$st->execute([$id]);$d=$st->fetch();
if(!$d){http_response_code(404);exit('Dokumen tidak ditemukan.');}
$path=UPLOAD_DIR.'/dokumen/'.$d['stored_name'];if(!is_file($path)){http_response_code(404);exit('File tidak tersedia.');}
header('X-Content-Type-Options: nosniff');header('Content-Type: application/octet-stream');header('Content-Length: '.filesize($path));header('Content-Disposition: attachment; filename="'.str_replace('"','',basename($d['original_name'])).'"');readfile($path);exit;
