<?php
declare(strict_types=1);
define('APP_NAME', 'SIABSEN');
define('BASE_URL', '/siabsen');
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'siabsen');
define('DB_USER', 'root');
define('DB_PASS', '');
define('UPLOAD_DIR', dirname(__DIR__) . '/uploads');
date_default_timezone_set('Asia/Jakarta');
if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params(['httponly'=>true, 'samesite'=>'Lax', 'secure'=>!empty($_SERVER['HTTPS'])]);
    session_start();
}
