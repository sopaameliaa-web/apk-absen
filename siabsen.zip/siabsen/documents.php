<?php
require_once __DIR__.'/includes/functions.php'; require_login();
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();
 try{
  if(current_user()['role']!=='admin')throw new RuntimeException('Hanya TU/Admin yang boleh mengunggah dokumen.');
  if(empty($_FILES['file'])||$_FILES['file']['error']!==UPLOAD_ERR_OK)throw new RuntimeException('Pilih file yang valid.');
  $f=$_FILES['file'];if($f['size']>15*1024*1024)throw new RuntimeException('Ukuran maksimum 15 MB.');
  $allowed=['pdf'=>'application/pdf','doc'=>'application/msword','docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document','xls'=>'application/vnd.ms-excel','xlsx'=>'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg'];
  $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));if(!isset($allowed[$ext]))throw new RuntimeException('Format diizinkan: PDF, Word, Excel, PNG, JPG.');
  $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);if($mime!==$allowed[$ext] && !($ext==='doc'&&$mime==='application/CDFV2'))throw new RuntimeException('Tipe file tidak sesuai ekstensi.');
  if(!is_dir(UPLOAD_DIR.'/dokumen'))mkdir(UPLOAD_DIR.'/dokumen',0750,true);
  $stored=bin2hex(random_bytes(20)).'.'.$ext;if(!move_uploaded_file($f['tmp_name'],UPLOAD_DIR.'/dokumen/'.$stored))throw new RuntimeException('Gagal menyimpan file.');
  $st=db()->prepare('INSERT INTO documents(title,original_name,stored_name,mime_type,file_size,uploaded_by) VALUES(?,?,?,?,?,?)');
  $st->execute([trim((string)($_POST['title']??pathinfo($f['name'],PATHINFO_FILENAME))),basename($f['name']),$stored,$mime,$f['size'],current_user()['id']]);
  flash('Dokumen berhasil diunggah.');redirect('documents.php');
 }catch(Throwable $e){$error=$e->getMessage();}
}
$docs=db()->query('SELECT d.*,u.full_name AS uploader FROM documents d JOIN users u ON u.id=d.uploaded_by ORDER BY d.created_at DESC')->fetchAll();
layout_header('Dokumen');echo '<h1 class="h3 mb-3">Dokumen sekolah</h1>';
if($error)echo '<div class="alert alert-danger">'.e($error).'</div>';
if(current_user()['role']==='admin'){echo '<form method="post" enctype="multipart/form-data" class="card card-body mb-4">'.csrf_field().'<div class="row g-3"><div class="col-md-4"><label class="form-label">Judul dokumen</label><input class="form-control" name="title" required></div><div class="col-md-5"><label class="form-label">Pilih file (maks. 15 MB)</label><input class="form-control" type="file" name="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg" required></div><div class="col-md-3 d-flex align-items-end"><button class="btn btn-primary w-100">Upload dokumen</button></div></div></form>';}
echo '<div class="card"><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Judul</th><th>Nama file</th><th>Ukuran</th><th>Pengunggah</th><th>Tanggal</th><th></th></tr></thead><tbody>';
foreach($docs as $d)echo '<tr><td>'.e($d['title']).'</td><td>'.e($d['original_name']).'</td><td>'.number_format($d['file_size']/1024,1).' KB</td><td>'.e($d['uploader']).'</td><td>'.e($d['created_at']).'</td><td><a class="btn btn-sm btn-outline-primary" href="'.e(url('download.php?id='.(int)$d['id'])).'">Unduh</a></td></tr>';
if(!$docs)echo '<tr><td colspan="6" class="text-center text-secondary py-4">Belum ada dokumen.</td></tr>';echo '</tbody></table></div></div>';layout_footer();
