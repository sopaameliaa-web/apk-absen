# SIABSEN — PHP Native + MySQL/MariaDB + XAMPP

## Kebutuhan
- XAMPP dengan PHP 8.1+ dan MySQL/MariaDB
- Browser modern; kamera berjalan di `localhost` atau HTTPS
- Internet untuk Bootstrap 5, html5-qrcode, dan ekspor Composer (opsional)

## Instalasi
1. Ekstrak folder `siabsen` ke `C:\xampp\htdocs\siabsen`.
2. Jalankan Apache dan MySQL dari XAMPP.
3. Buka `http://localhost/phpmyadmin`, buat/import database dengan mengimpor `database/siabsen.sql`.
4. Sesuaikan `config/config.php` bila kredensial MySQL berbeda.
5. Buka `http://localhost/siabsen/setup.php` satu kali untuk membuat akun awal. Hapus `setup.php` setelah berhasil.
6. Login di `http://localhost/siabsen/login.php`.

Akun awal:
- TU/Admin: `admin` / `Admin123!`
- Guru: `guru` / `Guru123!`
- Wali kelas: `wali` / `Wali123!`

Ganti semua kata sandi awal setelah login. Akun contoh hanya untuk instalasi lokal.

## Scan QR di gerbang
- Login sebagai TU/Admin lalu buka menu **QR & Gerbang** dan cetak/unduh QR token untuk orang yang sudah terdaftar.
- Buka halaman scan pada perangkat kamera gerbang: `http://localhost/siabsen/scan.php`.
- QR berisi token acak, bukan ID berurutan. Setelah QR valid, halaman meminta/menyalakan kamera foto dan menyimpan bukti foto bersama waktu server.
- Browser akan meminta izin kamera. Pastikan perangkat berada di `localhost` atau HTTPS.
- Mode foto otomatis tetap bergantung pada izin kamera dan kebijakan browser. Sistem tidak melakukan pengenalan wajah.
- QR token pribadi jangan dipublikasikan. Fitur anti-scan-ganda berlaku untuk jenis dan tanggal yang sama.

## Fitur
- Login dengan password_hash/password_verify, session regeneration, CSRF, prepared statements, role checks.
- Pengelolaan data siswa/guru/wali kelas, kelas, mapel, jadwal.
- QR absensi datang/pulang siswa dan guru dengan foto bukti.
- Absensi kelas oleh guru berdasarkan kelas, mapel, tanggal, dan pertemuan.
- Rekap, filter, ekspor CSV yang kompatibel dengan Excel, serta tampilan cetak/Simpan sebagai PDF.
- Dokumen unggah/unduh dengan validasi tipe dan nama file acak.
- Ekspor Word/Excel/PDF tingkat lanjut tersedia melalui Composer (`composer install`); lihat `exports.php`.

## Ekspor
- CSV bisa dibuka oleh Excel.
- Tombol Cetak membuka dialog browser; pilih “Save as PDF”.
- Untuk `.xlsx`, `.docx`, dan PDF server-side jalankan `composer install` dari folder proyek, lalu gunakan menu Ekspor. Paket yang disiapkan: PhpSpreadsheet, PHPWord, Dompdf.
- Kalau Composer belum tersedia, CSV dan cetak browser tetap berfungsi.

## Catatan produksi
Ini adalah fondasi aplikasi sekolah yang dapat dijalankan dan dikembangkan, bukan sertifikasi keamanan/produksi. Sebelum dipakai sungguhan: pasang HTTPS, batasi akses direktori `uploads`, backup berkala, ganti password contoh, atur retensi foto, uji beban, dan lakukan audit keamanan. Foto absensi adalah data pribadi; sampaikan kebijakan privasi dan batasi akses.
