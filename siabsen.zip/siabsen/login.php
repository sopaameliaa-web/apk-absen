<?php
require_once __DIR__.'/includes/functions.php';
if(current_user()) redirect('dashboard.php');
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();
 $username=trim((string)($_POST['username']??'')); $password=(string)($_POST['password']??'');
 $st=db()->prepare('SELECT * FROM users WHERE username=? AND active=1 LIMIT 1'); $st->execute([$username]); $u=$st->fetch();
 if($u && password_verify($password,$u['password_hash'])){
  session_regenerate_id(true); unset($u['password_hash']); $_SESSION['user']=$u; log_activity('Login'); redirect('dashboard.php');
 } else $error='Username atau kata sandi salah.';
}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login SIABSEN</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="<?=e(url('assets/style.css'))?>" rel="stylesheet"></head><body class="login-bg"><div class="card login-card shadow"><div class="card-body p-4 p-md-5"><div class="text-center mb-4"><div class="brand-icon">S</div><h1 class="h3 fw-bold">SIABSEN</h1><p class="text-secondary">Sistem Informasi Absensi Sekolah</p></div><?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif?><form method="post"><?=csrf_field()?><div class="mb-3"><label class="form-label">Username</label><input class="form-control form-control-lg" name="username" autocomplete="username" required autofocus></div><div class="mb-4"><label class="form-label">Kata sandi</label><input class="form-control form-control-lg" type="password" name="password" autocomplete="current-password" required></div><button class="btn btn-primary btn-lg w-100">Masuk</button></form><p class="small text-secondary mt-4 mb-0">Untuk instalasi lokal, jalankan setup.php satu kali.</p></div></div></body></html>
