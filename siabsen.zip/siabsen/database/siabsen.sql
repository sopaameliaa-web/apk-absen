CREATE DATABASE IF NOT EXISTS siabsen CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE siabsen;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS activity_logs, documents, lesson_attendance, gate_attendance, qr_tokens, schedules, subjects, students, teachers, school_classes, users;
SET FOREIGN_KEY_CHECKS=1;
CREATE TABLE users (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(60) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 full_name VARCHAR(150) NOT NULL,
 role ENUM('admin','guru','wali') NOT NULL,
 teacher_id INT UNSIGNED NULL,
 class_id INT UNSIGNED NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE school_classes (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(80) NOT NULL UNIQUE, grade_level VARCHAR(30) NULL,
 homeroom_user_id INT UNSIGNED NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE teachers (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nip VARCHAR(40) NULL UNIQUE, full_name VARCHAR(150) NOT NULL,
 email VARCHAR(150) NULL, phone VARCHAR(40) NULL, qr_token CHAR(64) NOT NULL UNIQUE, active TINYINT(1) DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE students (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nis VARCHAR(40) NOT NULL UNIQUE, full_name VARCHAR(150) NOT NULL,
 class_id INT UNSIGNED NOT NULL, gender ENUM('L','P') NULL, qr_token CHAR(64) NOT NULL UNIQUE,
 active TINYINT(1) DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_student_class FOREIGN KEY(class_id) REFERENCES school_classes(id)
) ENGINE=InnoDB;
CREATE TABLE subjects (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, subject_code VARCHAR(30) NULL
) ENGINE=InnoDB;
CREATE TABLE schedules (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, teacher_id INT UNSIGNED NOT NULL, class_id INT UNSIGNED NOT NULL,
 subject_id INT UNSIGNED NOT NULL, day_name VARCHAR(15) NULL, start_time TIME NOT NULL, end_time TIME NOT NULL,
 FOREIGN KEY(teacher_id) REFERENCES teachers(id), FOREIGN KEY(class_id) REFERENCES school_classes(id),
 FOREIGN KEY(subject_id) REFERENCES subjects(id)
) ENGINE=InnoDB;
CREATE TABLE qr_tokens (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, person_type ENUM('student','teacher') NOT NULL,
 person_id INT UNSIGNED NOT NULL, token CHAR(64) NOT NULL UNIQUE, active TINYINT(1) DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_person(person_type,person_id)
) ENGINE=InnoDB;
CREATE TABLE gate_attendance (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, person_type ENUM('student','teacher') NOT NULL,
 person_id INT UNSIGNED NOT NULL, attendance_date DATE NOT NULL, attendance_type ENUM('in','out') NOT NULL,
 scanned_at DATETIME NOT NULL, photo_path VARCHAR(255) NOT NULL, recorded_by INT UNSIGNED NULL,
 UNIQUE KEY uq_gate(person_type,person_id,attendance_date,attendance_type),
 INDEX idx_gate_date(attendance_date), FOREIGN KEY(recorded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE lesson_attendance (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, class_id INT UNSIGNED NOT NULL, student_id INT UNSIGNED NOT NULL,
 teacher_id INT UNSIGNED NOT NULL, subject_id INT UNSIGNED NOT NULL, lesson_date DATE NOT NULL,
 meeting_no SMALLINT UNSIGNED NOT NULL, start_time TIME NULL, end_time TIME NULL,
 status ENUM('hadir','terlambat','izin','sakit','alpa') NOT NULL DEFAULT 'hadir', note VARCHAR(255) NULL,
 created_by INT UNSIGNED NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_lesson(student_id,subject_id,lesson_date,meeting_no),
 INDEX idx_lesson_date(lesson_date), FOREIGN KEY(class_id) REFERENCES school_classes(id),
 FOREIGN KEY(student_id) REFERENCES students(id), FOREIGN KEY(teacher_id) REFERENCES teachers(id),
 FOREIGN KEY(subject_id) REFERENCES subjects(id), FOREIGN KEY(created_by) REFERENCES users(id)
) ENGINE=InnoDB;
CREATE TABLE documents (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, title VARCHAR(180) NOT NULL, original_name VARCHAR(255) NOT NULL,
 stored_name VARCHAR(255) NOT NULL, mime_type VARCHAR(120) NOT NULL, file_size BIGINT UNSIGNED NOT NULL,
 uploaded_by INT UNSIGNED NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(uploaded_by) REFERENCES users(id)
) ENGINE=InnoDB;
CREATE TABLE activity_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NULL, action VARCHAR(255) NOT NULL,
 ip_address VARCHAR(45) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
