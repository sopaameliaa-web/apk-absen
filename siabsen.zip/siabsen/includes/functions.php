<?php
require_once __DIR__ . '/../config/database.php';
function e(?string $s): string { return htmlspecialchars($s ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function url(string $path=''): string { return BASE_URL . '/' . ltrim($path, '/'); }
function redirect(string $path): never { header('Location: '.url($path)); exit; }
function csrf_token(): string { if (empty($_SESSION['_csrf'])) $_SESSION['_csrf']=bin2hex(random_bytes(32)); return $_SESSION['_csrf']; }
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="'.e(csrf_token()).'">'; }
function verify_csrf(): void {
    $token = $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($token) || !hash_equals(csrf_token(), $token)) { http_response_code(419); exit('Token keamanan kedaluwarsa. Muat ulang halaman.'); }
}
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): void { if (!current_user()) redirect('login.php'); }
function require_roles(array $roles): void { require_login(); if (!in_array(current_user()['role'], $roles, true)) { http_response_code(403); exit('Akses ditolak.'); } }
function flash(string $msg, string $type='success'): void { $_SESSION['_flash']=['msg'=>$msg,'type'=>$type]; }
function show_flash(): void { if (!empty($_SESSION['_flash'])) { $f=$_SESSION['_flash']; unset($_SESSION['_flash']); echo '<div class="alert alert-'.e($f['type']).'">'.e($f['msg']).'</div>'; } }
function log_activity(string $action): void {
    try { $st=db()->prepare('INSERT INTO activity_logs(user_id,action,ip_address,created_at) VALUES(?,?,?,NOW())'); $st->execute([current_user()['id'] ?? null,$action,substr($_SERVER['REMOTE_ADDR'] ?? '',0,45)]); } catch(Throwable $e) {}
}
function layout_header(string $title): void {
    $u=current_user();
    echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'.e($title).' - '.APP_NAME.'</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="'.e(url('assets/style.css')).'" rel="stylesheet"></head><body>';
    echo '<nav class="navbar navbar-expand-lg navbar-dark bg-primary"><div class="container-fluid"><a class="navbar-brand fw-bold" href="'.e(url('dashboard.php')).'">SIABSEN</a><button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="nav"><div class="navbar-nav me-auto">';
    if($u) {
        echo '<a class="nav-link" href="'.e(url('dashboard.php')).'">Dashboard</a>';
        if(in_array($u['role'],['admin','guru'],true)) echo '<a class="nav-link" href="'.e(url('class_attendance.php')).'">Absensi Kelas</a>';
        if($u['role']==='admin') echo '<a class="nav-link" href="'.e(url('manage.php')).'">Data Master</a><a class="nav-link" href="'.e(url('scan.php')).'">QR & Gerbang</a>';
        echo '<a class="nav-link" href="'.e(url('reports.php')).'">Rekap</a><a class="nav-link" href="'.e(url('documents.php')).'">Dokumen</a>';
    }
    echo '</div><div class="navbar-nav">';
    if($u) echo '<span class="navbar-text me-lg-3">'.e($u['full_name']).' ('.e($u['role']).')</span><a class="nav-link" href="'.e(url('logout.php')).'">Keluar</a>';
    echo '</div></div></div></nav><main class="container-fluid px-3 px-lg-4 py-4">';
    show_flash();
}
function layout_footer(): void { echo '</main><footer class="text-center text-secondary py-4 small">SIABSEN · Sistem Informasi Absensi Sekolah</footer><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script></body></html>'; }
